package com.kcc.security2.filter;

import jakarta.servlet.*;

import java.io.IOException;

public class MyFilter2 implements Filter {

    @Override
    public void doFilter(ServletRequest request,ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {
        System.out.println("filter2...........");
        chain.doFilter(request, response);
    }
}
